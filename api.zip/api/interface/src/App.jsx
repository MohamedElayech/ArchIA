import { useState } from "react";
// import axios from "axios";
import "./App.css";
import Nav from "./components/Nav"
import Content from "./components/Content";

function App() {

  return (
    <div>
      {/* <Nav></Nav> */}
      <Content></Content>
    </div>
  );
}

export default App;
