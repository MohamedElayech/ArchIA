

export default function Nav(){
    return (
        <div>
            nav
            {/* <span style={'color:white;'}>logo</span>
            <span style={'color:white;'}>welcome</span> */}
        </div>
    )
    
    
}