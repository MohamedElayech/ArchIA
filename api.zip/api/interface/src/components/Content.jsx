import { useState } from "react";
import Zoom from 'react-medium-image-zoom';
import 'react-medium-image-zoom/dist/styles.css';
import "./content.css";
function Content() {
  const [paragraph, setParagraph] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [error, setError] = useState("");
  const [elements , setElements] = useState([]);
  const [imageSrc, setImageSrc] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  var elms = [] ;


  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setImageSrc("");
    setLoading(true); 
  
    let data = {
      "desc": paragraph,
      "elements": elements
    };
    try{
      console.log("Sending data:", data);
    
      const response = await fetch("http://localhost:8080/text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({data})
      });
    
      const resJson = await response.json();
      console.log("Received from server:", resJson);

      if (resJson!= null) {
        // 2. Send GET to fetch the generated image
        const imageUrl = 'http://localhost:8080/text';
        setImageSrc(imageUrl);
        console.log("image done")
      } else {
        console.error('Image generation failed:', resJson.error);
      } 
    }catch (err) {
      console.error("Error during fetch:", err);
    } finally {
      setLoading(false); // hide the loading message
    }
  };
  const handlechek = async (e) =>{
    const elm = e.target.name
    const isChecked = e.target.checked;
    setElements((prev) => {
        if (isChecked) {
          return [...prev,elm]; // add if checked
        } else {
          return prev.filter((item) => item !== elm); // remove if unchecked
        }
      });
    
  }

  return (
    <div className="container">
      <h1>Archimate Diagram Generator</h1>
      <h4>Enter your project description, chose layers and press generate</h4>
      <form onSubmit={handleSubmit}>
        <textarea
          rows={6}
          placeholder="Enter a paragraph"
          value={paragraph}
          onChange={(e) => setParagraph(e.target.value)}
        />
        <div className="check_container">
            <span className="chek">
                <input type="checkbox" id="Business" name="Business" onChange={handlechek}/>
                <label htmlFor="">Business</label>
            </span>
            <span className="chek">
                <input type="checkbox" id="Application" name="Application" onChange={handlechek}/>
                <label htmlFor="">Application</label>
            </span>
            <span className="chek">
                <input type="checkbox" id="Motivation" name="Motivation" onChange={handlechek}/>
                <label htmlFor="">Motivation</label>
            </span>
            <span className="chek">
                <input type="checkbox" id="Technologie" name="Technologie" onChange={handlechek}/>
                <label htmlFor="">Technologie</label>
            </span>
            <span className="chek">
                <input type="checkbox" id="Strategy" name="Strategy" onChange={handlechek}/>
                <label htmlFor="">Strategy</label>
            </span>
        </div>
        <button type="submit">Generate Image</button>
      </form>
      {loading && <p>This may take a while, please wait...</p>}
      {imageSrc && (
        <div className="image-container">
          <Zoom>
            <img
              src={imageSrc}
              alt="Generated"
              style={{
                display: imageSrc ? "block" : "none",
                height: "auto",
                objectFit: "contain"
              }}
              onError={(e) => {
                e.target.style.display = "none";
                console.error("Failed to load image:", imageSrc);
              }}
            />
          </Zoom>
          <a 
            href={"https://viewer.diagrams.net/?tags={}&lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&title=diagram&dark=auto#R%3Cmxfile%20version%3D%221.0%22%20encoding%3D%22UTF-8%22%3E%3Cdiagram%20name%3D%22Page-1%22%20id%3D%220%22%20url%3D%22www.draw.io%22%3E%3CmxGraphModel%20dx%3D%221200%22%20dy%3D%22800%22%20grid%3D%221%22%3E%3Croot%3E%3CmxCell%20id%3D%220%22%20/%3E%3CmxCell%20id%3D%221%22%20parent%3D%220%22%20/%3E%3CmxCell%20id%3D%22elem_element_1%22%20value%3D%22Enhanced%20Digital%20Banking%20Experience%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dgoal%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%221278.79%22%20y%3D%22493.75%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_2%22%20value%3D%22Unified%20Banking%20App%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23b5ffff%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dcomp%3BarchiType%3Dsquare%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%22562.12%22%20y%3D%22306.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_3%22%20value%3D%22Machine%20Learning%20Analysis%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23ffffb5%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dfunc%3BarchiType%3Drounded%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%22203.7835%22%20y%3D%22118.75%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_4%22%20value%3D%22Robust%20Security%20Measures%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23b5ffff%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dpassive%3BarchiType%3Dsquare%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%22562.12%22%20y%3D%22118.75%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_5%22%20value%3D%22Customer%20Satisfaction%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dgoal%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%22920.4549999999999%22%20y%3D%22306.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_6%22%20value%3D%22Market%20Competitiveness%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Ddriver%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%221278.79%22%20y%3D%22681.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_7%22%20value%3D%22Enhanced%20Business%20Banking%20Tools%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23ffffb5%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dproc%3BarchiType%3Drounded%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%22920.4549999999999%22%20y%3D%22118.75%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_8%22%20value%3D%22Increased%20User%20Engagement%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dgoal%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%221278.79%22%20y%3D%22306.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_9%22%20value%3D%22Higher%20Loan%20Applications%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dgoal%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%221637.05%22%20y%3D%22306.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22elem_element_10%22%20value%3D%22Improved%20NPS%20Scores%22%20style%3D%22html%3D1%3BoutlineConnect%3D0%3BwhiteSpace%3Dwrap%3BfillColor%3D%23CCCCFF%3Bshape%3Dmxgraph.archimate3.application%3BappType%3Dgoal%3BarchiType%3Doct%3B%22%20vertex%3D%221%22%20parent%3D%221%22%3E%3CmxGeometry%20x%3D%222003.8%22%20y%3D%22306.25%22%20width%3D%22150%22%20height%3D%2275%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_6_elem_element_1%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dassignment%3B%22%20edge%3D%221%22%20source%3D%22elem_element_6%22%20target%3D%22elem_element_1%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_1_elem_element_2%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Drealization%3B%22%20edge%3D%221%22%20source%3D%22elem_element_1%22%20target%3D%22elem_element_2%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_2_elem_element_3%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Drealization%3B%22%20edge%3D%221%22%20source%3D%22elem_element_2%22%20target%3D%22elem_element_3%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_2_elem_element_4%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dserving%3B%22%20edge%3D%221%22%20source%3D%22elem_element_2%22%20target%3D%22elem_element_4%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_1_elem_element_5%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dassignment%3B%22%20edge%3D%221%22%20source%3D%22elem_element_1%22%20target%3D%22elem_element_5%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_2_elem_element_7%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Drealization%3B%22%20edge%3D%221%22%20source%3D%22elem_element_2%22%20target%3D%22elem_element_7%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_1_elem_element_8%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dassignment%3B%22%20edge%3D%221%22%20source%3D%22elem_element_1%22%20target%3D%22elem_element_8%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_1_elem_element_9%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dassignment%3B%22%20edge%3D%221%22%20source%3D%22elem_element_1%22%20target%3D%22elem_element_9%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3CmxCell%20id%3D%22conn_elem_element_1_elem_element_10%22%20style%3D%22html%3D1%3Bshape%3Dmxgraph.archimate3.relationship%3BarchiType%3Dassignment%3B%22%20edge%3D%221%22%20source%3D%22elem_element_1%22%20target%3D%22elem_element_10%22%20parent%3D%221%22%3E%3CmxGeometry%20relative%3D%221%22%20as%3D%22geometry%22%20/%3E%3C/mxCell%3E%3C/root%3E%3C/mxGraphModel%3E%3C/diagram%3E%3C/mxfile%3E"} 
            download="archimate-diagram.png"
            className="download-button"
          >
            View Drow.io version
          </a>
        </div>
      )}
          
      {/* {error && <p className="error">{error}</p>}
      {imageUrl && <img src={imageUrl} alt="Generated" className="result-image" />} */}
    </div>
  );
}

export default Content;